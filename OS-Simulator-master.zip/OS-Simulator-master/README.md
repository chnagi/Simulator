# OS-Simulator
Simulator -Scheduling Algorithms
This project consists of CPU Scheduling,Page Replacement and Disk Scheduling algorithms.
It also consists of Dining Philosophers using Tannenbaum Solution.
By running main2.java file, you will be able to run the project.
