package order;


public class testing{
	int print()
	{
		int k=2;
		return k;
		
	}
}